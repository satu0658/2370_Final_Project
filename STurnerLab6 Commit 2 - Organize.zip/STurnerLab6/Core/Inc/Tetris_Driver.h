/*
 * Tetris_Driver.h
 *
 *  Created on: Dec 9, 2024
 *      Author: smtur
 */

#ifndef INC_TETRIS_DRIVER_H_
#define INC_TETRIS_DRIVER_H_

#include "stm32f4xx_hal.h"
#include "ili9341.h"
#include "fonts.h"
#include "stmpe811.h"
#include "RNG_Handler.h"
#include "Scheduler.h"
#include "Tetris_Driver.h"
#include <string.h>


#define NINETY 90
#define X_START 96
#define Y_START 18
#define ZERO_DEGREES 0
typedef struct{

	uint8_t Shape[4][4];
	uint16_t x;
	uint16_t y;
	uint32_t type;
	uint16_t color;
	uint16_t rotation;
	uint8_t height;
}Block_RegDef_t;

void gameScreen(void);

uint16_t drawBlock(Block_RegDef_t block);
void eraseBlock(Block_RegDef_t block);

Block_RegDef_t dropBlock(Block_RegDef_t block);

void LCD_Error_Handler(void);

void mainMenu(void);

uint8_t GenerateRandomBlock(void);
#endif /* INC_TETRIS_DRIVER_H_ */
