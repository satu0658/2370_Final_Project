/*
 * ErrorHandling.c
 *
 *  Created on: Nov 5, 2024
 *      Author: smtur
 */
#include "ErrorHandling.h"

void APPLICATION_ASSERT(bool flag){
	if(!flag){
		while(1){

		}
	}
}

